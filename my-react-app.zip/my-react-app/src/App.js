import logo from './circle.svg';
import sun from './sun.svg';
import './App.css';
import { useEffect, useState } from 'react';

function App() {
  let [message, setMessage] = useState("not clicked yet");
  let [count, setCount] = useState(0);
  const [cityname, setCityname] = useState("London");
  let [weather, setWeather] = useState("");

  // Fetch weather data when cityname changes
  useEffect(() => {
    let getWeather = async () => {
      try {
        let response = await fetch(`https://wttr.in/${cityname}`);
        let data = await response.text();
        setWeather(data);
      } catch (error) {
        console.log(error);
      }
    };
    getWeather();
  }); // Triggered when city changes

  // Function to handle city input change
  const handleCityChange = (e) => {
    setCityname(e.target.value); // Update city on input change
  };

  // Handle 'Enter' key press to fetch weather
  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      setCityname(e.target.value); // Trigger the API call when 'Enter' is pressed
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="App-weather">
          <img src={sun} className="sun-logo" alt="sun" />
          <div className="App-wether-content">
            <h1>Weather App</h1>
            {/* Input field to change city */}
            <input
              type="text"
              value={cityname}
              onChange={handleCityChange}
              onKeyDown={handleKeyPress} // Trigger API call on Enter
              placeholder="Enter city"
              className="city-input"
            />
            {/* Display weather report */}
            
            <div
              className="weather-html-content"
              dangerouslySetInnerHTML={{
                __html: weather || "Loading weather..."
              }}
            />
          </div>
        </div>

        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Started learning React : {message} : {count} times
        </p>
        <div className="button-container">
          <button
            className="styled-button"
            onClick={() => { setCount(prevCount => prevCount + 1); setMessage("Button Clicked!") }}
          >
            Click Me
          </button>
          <button
            className="styled-button"
            onClick={() => { setCount(0); setMessage("Button Reset!") }}
          >
            Reload
          </button>
        </div>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
