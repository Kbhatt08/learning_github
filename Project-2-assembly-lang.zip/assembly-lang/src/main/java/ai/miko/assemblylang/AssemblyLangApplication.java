package ai.miko.assemblylang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssemblyLangApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssemblyLangApplication.class, args);
	}

}
